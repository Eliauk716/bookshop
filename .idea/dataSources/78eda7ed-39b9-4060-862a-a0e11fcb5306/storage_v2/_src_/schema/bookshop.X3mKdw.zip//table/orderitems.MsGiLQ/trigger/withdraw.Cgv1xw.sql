create definer = root@localhost trigger withdraw
    after DELETE
    on orderitems
    for each row
BEGIN
  DECLARE num INT DEFAULT 0;
  set num = old.quantity;

  UPDATE book
  set quantity = quantity + num
  WHERE b_id = old.b_id;

END;

