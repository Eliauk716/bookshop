create definer = root@localhost trigger sell
    after INSERT
    on orderitems
    for each row
BEGIN
  DECLARE num INT DEFAULT 0;
  set num = new.quantity;

  UPDATE book
  set quantity = quantity - num
  WHERE b_id = new.b_id;

END;

