create
    definer = root@localhost procedure add_op()
BEGIN
  DECLARE id char(20) DEFAULT NULL;
  DECLARE price DECIMAL(10,2);
  
  declare cur cursor for select f_id from fruits;
	declare exit handler for not found close cur;

  open cur;

  read_loop:loop 
    FETCH cur INTO id;

    set price = (SELECT f_price from fruits where f_id = id) * 0.8;
    
    UPDATE fruits
    set o_price = price
    where f_id = id;

    end loop;

  close cur;
END;

