create definer = root@localhost trigger f_update
    after UPDATE
    on fruits
    for each row
    insert into opertation(tablename, opname, optime) VALUES('fruits', 'update', LOCALTIME);

