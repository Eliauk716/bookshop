create definer = root@localhost trigger xginsert
    after UPDATE
    on orderitems
    for each row
BEGIN
  DECLARE price DECIMAL(10,2) DEFAULT 0;
  set price = new.quantity * new.item_price;

  UPDATE orders
  set original_price = price
  WHERE o_num = new.o_num;

  update orders
  set pay = original_price * discount
  where o_num = new.o_num;
  
END;

