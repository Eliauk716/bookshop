create
    definer = root@localhost procedure amend()
BEGIN
  DECLARE id char(50) DEFAULT NULL;
  DECLARE o_price DECIMAL(8,2);
  DECLARE price DECIMAL(8,2);

  declare cur cursor for select f_id from orderitems;
	declare exit handler for not found close cur;

  open cur;

  read_loop:loop 
    FETCH cur INTO id;

    set o_price = (SELECT orderitems.item_price
    from fruits, orderitems
    where (fruits.f_id = orderitems.f_id) AND (orderitems.f_id = id) LIMIT 1);

    set price = (SELECT fruits.f_price
    from fruits, orderitems
    where (fruits.f_id = orderitems.f_id) AND (orderitems.f_id = id) LIMIT 1);
    
    if o_price != price then 
       UPDATE orderitems
       set item_price = price
       WHERE orderitems.f_id = id;
       
    end if;
    
    end loop;

  close cur;
END;

