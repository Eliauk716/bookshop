create definer = root@localhost trigger c_delete
    after DELETE
    on customers
    for each row
    insert into opertation(tablename, opname, optime) VALUES('customers', 'delete', LOCALTIME);

