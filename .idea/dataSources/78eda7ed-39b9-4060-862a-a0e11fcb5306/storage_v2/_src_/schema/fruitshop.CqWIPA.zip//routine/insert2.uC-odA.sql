create
    definer = root@localhost procedure insert2()
begin
	declare exist int default 0;
	declare u_id int; 
	declare pwd blob; 
	declare remark varchar(255); 
	
	declare cur cursor for select s_id,AES_ENCRYPT('123456', 'hello'),'supplier' from suppliers;
	declare exit handler for not found close cur;

	open cur; 
	 
	read_cur:loop 
		fetch cur into u_id,pwd,remark; 
		select count(1) into exist from user where `user`.u_id=u_id;

		if exist=0 then
			insert into user(u_id,pwd,remark) values(u_id,pwd,remark);
		end if;

	end loop read_cur;

	close cur; 
end;

