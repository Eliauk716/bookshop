create
    definer = root@localhost procedure rec()
BEGIN
  DECLARE no char(20) DEFAULT NULL;
  DECLARE price DECIMAL(10,2) DEFAULT 0;
  declare cur cursor for select o_num from orders;
	declare exit handler for not found close cur;

  open cur;

  read_cur:LOOP
    FETCH cur into no;
    
    set price = (select sum(quantity * item_price)
    from orderitems
    GROUP BY o_num
    HAVING o_num = NO);
 
    UPDATE orders
    set original_price = price
    where o_num = no;
    
    UPDATE orders
    set pay = original_price * discount
    where o_num = no;

    END loop;

END;

