create
    definer = root@localhost procedure cus_user()
begin
	declare isExi int default 0; #判断用户是否存在
	declare u_id int; #存放用户的id
	declare pwd blob; #存放用户的密码
	declare remark varchar(255); #存放用户标志
	
	#定义customers的游标
	declare cus_cur cursor for select c_id,AES_ENCRYPT('123456', 'hello'),'customer' from customers;
	#定义游标异常，如果游标结束则关闭游标退出
	declare exit handler for not found close cus_cur;

	open cus_cur; #打开游标
	 
	read_cur:loop #循环
		fetch cus_cur into u_id,pwd,remark; #取出一条记录
		#统计从游标中取出的用户是否存在
		select count(1) into isExi from user where `user`.u_id=u_id;
		#如果不存在该用户则插入，否则不插入，防止异常时主键空自增
		if isExi=0 then
			insert into user(u_id,pwd,remark) values(u_id,pwd,remark);
		end if;
	end loop read_cur;
	close cus_cur; #关闭游标
end;

