create definer = root@localhost trigger c_insert
    after INSERT
    on customers
    for each row
    insert into opertation(tablename, opname, optime) VALUES('customers', 'insert', LOCALTIME);

