create
    definer = root@localhost procedure add_profit()
BEGIN
  DECLARE num char(20) DEFAULT NULL;
  DECLARE pro DECIMAL(10,2);
  
  declare cur cursor for select o_num from orders;
	declare exit handler for not found close cur;

  open cur;

  read_loop:loop 
    FETCH cur INTO num;

    set pro = (SELECT pay from orders where o_num = num)
               - ((SELECT original_price from orders where o_num = num) * 0.8 );
    
    UPDATE orders
    set profit = pro
    where o_num = num;

    end loop;

  close cur;
END;

