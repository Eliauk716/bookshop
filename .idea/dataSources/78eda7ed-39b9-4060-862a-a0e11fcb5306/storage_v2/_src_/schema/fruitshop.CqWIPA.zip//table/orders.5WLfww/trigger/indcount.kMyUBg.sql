create definer = root@localhost trigger indcount
    before INSERT
    on orders
    for each row
BEGIN
  DECLARE o_vip INT DEFAULT 0;
  DECLARE count DECIMAL(10,2) DEFAULT 0;

  set o_vip = (SELECT vip
  from customers
  where c_id = new.c_id);
  
  if o_vip = 0
  then set count = 1;

  ELSEIF o_vip = 1
  then set count = 0.99;

  ELSEIF o_vip = 2
  then set count = 0.97;
  
  ELSEIF o_vip = 3
  then set count = 0.95;

  ELSEIF o_vip = 4
  then set count = 0.9;

  ELSE set count = 0.85;
  
  end if;

  set new.discount = count;
  set new.pay = new.original_price * new.discount;

END;

