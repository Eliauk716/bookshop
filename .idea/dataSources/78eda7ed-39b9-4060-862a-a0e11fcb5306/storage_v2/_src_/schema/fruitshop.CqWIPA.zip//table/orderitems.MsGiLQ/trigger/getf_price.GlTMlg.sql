create definer = root@localhost trigger getf_price
    before INSERT
    on orderitems
    for each row
BEGIN
 DECLARE price DECIMAL(8,2) DEFAULT 0;
 set price = 
 (SELECT f_price
  from fruits
  where new.f_id = f_id);
  set new.item_price = price;
END;

