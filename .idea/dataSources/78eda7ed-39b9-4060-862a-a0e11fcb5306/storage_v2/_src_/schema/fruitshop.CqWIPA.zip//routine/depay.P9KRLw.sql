create
    definer = root@localhost function depay(id char(20)) returns decimal(10, 2)
BEGIN
  DECLARE allpay DECIMAL(10,2) DEFAULT 0;
  DECLARE relpay DECIMAL(10,2) DEFAULT 0;

  set allpay = (select sum(original_price)
  from orders
  where c_id = id);

  set relpay = (select sum(pay)
  from orders
  where c_id = id);

  RETURN (allpay - relpay);
END;

