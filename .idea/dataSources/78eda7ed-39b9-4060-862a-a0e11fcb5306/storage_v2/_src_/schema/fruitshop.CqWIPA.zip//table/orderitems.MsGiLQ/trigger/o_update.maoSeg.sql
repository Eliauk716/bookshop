create definer = root@localhost trigger o_update
    after UPDATE
    on orderitems
    for each row
    UPDATE fruits 
set quantity = quantity - new.quantity
where f_id = new.f_id;

