create
    definer = root@localhost function sumprice(num int) returns decimal(8, 2)
BEGIN
	#Routine body goes here...
	RETURN (SELECT sum(quantity * item_price)
  from orderitems
  where o_num = num);
END;

