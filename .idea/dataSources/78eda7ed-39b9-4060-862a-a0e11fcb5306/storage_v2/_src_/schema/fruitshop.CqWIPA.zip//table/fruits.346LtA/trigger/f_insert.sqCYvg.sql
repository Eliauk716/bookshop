create definer = root@localhost trigger f_insert
    after INSERT
    on fruits
    for each row
    insert into opertation(tablename, opname, optime) VALUES('fruits', 'insert', LOCALTIME);

