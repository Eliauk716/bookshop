create
    definer = root@localhost function allpay(id char(20)) returns decimal(10, 2)
BEGIN
	#Routine body goes here...
  DECLARE allpay DECIMAL(10,2) DEFAULT 0;

  set allpay = (SELECT sum(pay)
  from orders
  where c_id = id);

	RETURN allpay;
END;

