create
    definer = root@localhost procedure invip()
BEGIN
  DECLARE id char(20) DEFAULT null;
	declare allpay DECIMAL(10,2) DEFAULT 0;

  declare cur cursor for select c_id from customers;
	declare exit handler for not found close cur;

  open cur;

  read_loop:loop 
    FETCH cur INTO id;

    set allpay = (SELECT sum(pay)
    from orders
    where c_id = id);
    
    if allpay > 100 and allpay < 199
    then UPDATE customers
    set vip = 1
    WHERE c_id = id;
    
		ELSEif allpay > 200 and allpay < 499
    then UPDATE customers
    set vip = 2
		WHERE c_id = id;

    elseif allpay > 500 and allpay < 999
    then UPDATE customers
    set vip = 3
    WHERE c_id = id;

    ELSEif allpay > 1000 and allpay < 1999
    then UPDATE customers
    set vip = 4
    WHERE c_id = id;

    ELSEif allpay >= 2000
    then UPDATE customers
    set vip = 5
    WHERE c_id = id;
    
    ELSE UPDATE customers
    set vip = 0
    WHERE c_id = id;

    end IF;

    end loop;

  close cur;
  
END;

