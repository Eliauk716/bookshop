create definer = root@localhost trigger scinsert
    after DELETE
    on orderitems
    for each row
BEGIN
  DECLARE price DECIMAL(10,2) DEFAULT 0;
  set price = old.quantity * old.item_price;

  UPDATE orders
  set original_price = original_price - price
  WHERE o_num = old.o_num;

  update orders
  set pay = original_price * discount
  where o_num = old.o_num;
  
END;

